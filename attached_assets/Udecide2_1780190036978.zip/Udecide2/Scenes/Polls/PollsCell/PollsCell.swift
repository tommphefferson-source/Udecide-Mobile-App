//
//  PollsCell.swift
//  Udecide
//
//  Created by hb on 25/04/19.
//  Copyright © 2019 hb. All rights reserved.
//

import UIKit

class PollsCell: UICollectionViewCell {
    
    @IBOutlet weak var remainingDays: UILabel!
    @IBOutlet weak var imgPrevious: UIImageView!
    @IBOutlet weak var btnPrevious: UIButton!
    @IBOutlet weak var skipline: UIImageView!
    @IBOutlet weak var option1WidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var option2WidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var btnSkip: UIButton!
    @IBOutlet weak var btnPollsResult: UIButton!
    @IBOutlet weak var viewOption2Name: UILabel!
    @IBOutlet weak var viewOption2Color: UIView!
    @IBOutlet weak var viewOption2Bg: UIView!
    @IBOutlet weak var lblOption2Percent: UILabel!
    @IBOutlet weak var viewOption1Name: UILabel!
    @IBOutlet weak var viewOption1Color: UIView!
    @IBOutlet weak var viewOption1Bg: UIView!
    @IBOutlet weak var viewOption2Result: UIView!
    @IBOutlet weak var lblOption1Percent: UILabel!
    @IBOutlet weak var viewOption1Result: UIView!
    @IBOutlet weak var lblTotalVotes: UILabel!
    @IBOutlet weak var btnOption2: UIButton!
    @IBOutlet weak var btnOption1: UIButton!
    @IBOutlet weak var viewPollResult: UIView!
    @IBOutlet weak var lblPollName: UILabel!
    @IBOutlet weak var viewPollOption: UIView!
    @IBOutlet weak var imgViewPoll: UIImageView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var buttonSkipClicked: ((Int)->())?
    var buttonPreviousClicked: ((Int)->())?
    var buttonOption2Clicked: ((Int)->())?
    var buttonOption1Clicked: ((Int)->())?
    var buttonPollResultClicked: ((Int)->())?
    var buttonImageClicked: ((Int)->())?
    
    static let cellId = "PollsCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        btnPollsResult.layer.shadowRadius = 3.0
        btnPollsResult.layer.shadowColor = UIColor.darkGray.cgColor
        btnPollsResult.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        btnPollsResult.layer.shadowOpacity = 0.5
        btnPollsResult.layer.masksToBounds = false
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.scrollView.layer.cornerRadius = 10
        self.btnPollsResult.layer.cornerRadius = 5
        self.viewOption1Bg.layer.cornerRadius = 5
        self.viewOption2Bg.layer.cornerRadius = 5
        
        self.btnOption1.layer.borderColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
        self.btnOption1.layer.cornerRadius = 5
        self.btnOption1.layer.borderWidth = 1
        self.btnOption2.layer.borderColor = #colorLiteral(red: 0.3333333433, green: 0.3333333433, blue: 0.3333333433, alpha: 1)
        self.btnOption2.layer.cornerRadius = 5
        self.btnOption2.layer.borderWidth = 1
        
        self.btnOption1.layoutIfNeeded()
        self.btnOption2.layoutIfNeeded()
        self.scrollView.layoutIfNeeded()
        self.btnPollsResult.layoutIfNeeded()
        self.viewOption1Bg.layoutIfNeeded()
        self.viewOption2Bg.layoutIfNeeded()
        self.layoutIfNeeded()
    }
    
    /// Set Polls data on cell
    ///
    /// - Parameter data: Polls model
    func setPollData(data: Polls.ViewModel) {
        self.imgViewPoll.setImage(with: data.pollImage)
        self.lblPollName.text = data.pollQuestion
        self.remainingDays.text = data.remainingDays
        self.btnOption1.setTitle(data.option1, for: UIControl.State())
        self.btnOption2.setTitle(data.option2, for: UIControl.State())
        self.viewPollResult.isHidden = true
        self.viewPollOption.isHidden = false
        
        self.btnSkip.isHidden = false
        self.skipline.isHidden = false
        self.btnPrevious.isHidden = false
        self.imgPrevious.isHidden = false
    }
    
    /// Set polls result data on cell
    ///
    /// - Parameter data: polls result model
    func setPollResult(data: PollSelect.ViewModel) {
        self.lblPollName.text = data.pollQuestion
        self.viewPollResult.isHidden = false
        self.viewPollOption.isHidden = true
        
        self.btnSkip.isHidden = true
        self.skipline.isHidden = true
        self.btnPrevious.isHidden = true
        self.imgPrevious.isHidden = true
        
        self.imgViewPoll.setImage(with: data.pollImage)
//        self.lblTotalVotes.text = "Total votes: \(data.totalVotes ?? "0")"
        self.viewOption1Name.text = data.option1
        self.viewOption2Name.text = data.option2
        self.lblOption1Percent.text = "\(data.option1Perc ?? "0")%"
        self.lblOption2Percent.text = "\(data.option2Perc ?? "0")%"
        
        UIView.animate(withDuration: 0.2) {
            let width = self.viewOption1Bg.frame.size.width
            self.option1WidthConstraint.constant = width * (CGFloat(Double(data.option1Perc ?? "0.0") ?? 0.0)/100.00)
            self.option2WidthConstraint.constant = width * (CGFloat(Double(data.option2Perc ?? "0.0") ?? 0.0)/100.00)
        }
    }
    
    @IBAction func btnOption2Tapped(_ sender: UIButton) {
        if buttonOption2Clicked != nil {
            self.buttonOption2Clicked!(sender.tag)
        }
    }
    
    @IBAction func btnOption1Tapped(_ sender: UIButton) {
        if buttonOption1Clicked != nil {
            self.buttonOption1Clicked!(sender.tag)
        }
    }
    
    @IBAction func btnPollResultTapped(_ sender: UIButton) {
        if buttonPollResultClicked != nil {
            self.buttonPollResultClicked!(sender.tag)
        }
    }
    
    @IBAction func btnSkipTapped(_ sender: UIButton) {
        if buttonSkipClicked != nil {
            self.buttonSkipClicked!(sender.tag)
        }
    }
    
    @IBAction func btnPreviousTapped(_ sender: UIButton) {
        if buttonPreviousClicked != nil {
            self.buttonPreviousClicked!(sender.tag)
        }
    }
    
    @IBAction func btnImgFullView(_ sender: UIButton) {
        if buttonImageClicked != nil {
            self.buttonImageClicked!(sender.tag)
        }
    }
    
}
