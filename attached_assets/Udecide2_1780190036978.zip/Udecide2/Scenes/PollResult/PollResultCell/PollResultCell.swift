//
//  PollResultCell.swift
//  Udecide
//
//  Created by hb on 25/04/19.
//  Copyright © 2019 hb. All rights reserved.
//

import UIKit

class PollResultCell: UITableViewCell {
    
    @IBOutlet weak var option1WidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var option2WidthConstraint: NSLayoutConstraint!
    @IBOutlet weak var viewOption2: UIView!
    @IBOutlet weak var viewOption2Color: UIView!
    @IBOutlet weak var viewOption1Color: UIView!
    @IBOutlet weak var viewOption1: UIView!
    @IBOutlet weak var lblOption2Precent: UILabel!
    @IBOutlet weak var lblOption2: UILabel!
    @IBOutlet weak var lblOption1Percent: UILabel!
    @IBOutlet weak var lblOption1: UILabel!
    @IBOutlet weak var lblYourVoteValue: UILabel!
    @IBOutlet weak var lblEndDateValue: UILabel!
    @IBOutlet weak var lblPollDiscription: UILabel!
    @IBOutlet weak var lblStartDateValue: UILabel!
    @IBOutlet weak var imgViewProfile: UIImageView!
    @IBOutlet weak var viewBG: UIView!
    
    var buttonImageClicked: ((Int)->())?
    
    static let cellId = "PollResultCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
        imgViewProfile.layer.shadowRadius = 3.0
        imgViewProfile.layer.shadowColor = UIColor.darkGray.cgColor
        imgViewProfile.layer.shadowOffset = CGSize(width: 0.0, height: 1.0)
        imgViewProfile.layer.shadowOpacity = 0.5
        self.selectionStyle = .none
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.viewBG.layer.cornerRadius = 10
        self.imgViewProfile.layer.cornerRadius = 5
        self.viewOption1.layer.cornerRadius = 5
        self.viewOption2.layer.cornerRadius = 5
        
        self.viewOption1.layoutIfNeeded()
        self.viewOption2.layoutIfNeeded()
        self.viewBG.layoutIfNeeded()
        self.imgViewProfile.layoutIfNeeded()
        self.layoutIfNeeded()
    }
    
    /// Set poll result data
    ///
    /// - Parameter data: Poll result model
    func setData(data: PollResult.ViewModel) {
        self.lblPollDiscription.text = data.pollQuestion
        self.lblStartDateValue.text = data.pollStartDate
        self.lblEndDateValue.text = data.pollEndDate
        self.imgViewProfile.setImage(with: data.pollImage)
        
        if data.userVotedFor == data.option1 {
            self.lblYourVoteValue.textColor = #colorLiteral(red: 0.1137254902, green: 0.5490196078, blue: 0.2941176471, alpha: 1)
        } else {
            self.lblYourVoteValue.textColor = #colorLiteral(red: 0.5882352941, green: 0.1529411765, blue: 0.262745098, alpha: 1)
        }
        self.lblYourVoteValue.text = data.userVotedFor
        self.lblOption1.text = data.option1
        self.lblOption2.text = data.option2
        self.lblOption1Percent.text = "\(data.option1Perc ?? "0")%"
        self.lblOption2Precent.text = "\(data.option2Perc ?? "0")%"
        
        UIView.animate(withDuration: 0.2) {
            let width = self.viewOption1.frame.size.width
            self.option1WidthConstraint.constant = width * (CGFloat(Double(data.option1Perc ?? "0.0") ?? 0.0)/100.00)
            self.option2WidthConstraint.constant = width * (CGFloat(Double(data.option2Perc ?? "0.0") ?? 0.0)/100.00)
        }
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    @IBAction func btnImageTapped(_ sender: UIButton) {
        if buttonImageClicked != nil {
            self.buttonImageClicked!(sender.tag)
        }
    }
    
}
