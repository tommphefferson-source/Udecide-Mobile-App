//
//  AppConstant.swift
//  Patient Data
//
//  Created by hb on 25/03/19.
//  Copyright © 2018 hb. All rights reserved.
//

import UIKit


struct AppConstants {
    static let appDelegate = UIApplication.shared.delegate as? AppDelegate ?? AppDelegate()
    static let screenWidth = UIScreen.main.bounds.size.width
    static let screenHeight = UIScreen.main.bounds.size.height
    
    static var statusBarHeight: CGFloat {
        if #available(iOS 13.0, *) {
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                return windowScene.statusBarManager?.statusBarFrame.height ?? 0
            }
            return 0
        } else {
            return UIApplication.shared.statusBarFrame.height
        }
    }
    
    static var statusBarWidth: CGFloat {
        if #available(iOS 13.0, *) {
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene {
                return windowScene.statusBarManager?.statusBarFrame.width ?? 0
            }
            return 0
        } else {
            return UIApplication.shared.statusBarFrame.width
        }
    }
    
    static let appName = "UDecide"
    
    //static let subscriptionId = "yearlysubscription"
    static let subscriptionId = "yearlysubscription2024"
    static let PROJ_ID = "proj-004410"
    static let reportAProblemSubject = "Udecide Feedback/Comment/Bug"
    static let reportProblemEmail = "udecidemobileapplication@gmail.com"
    
    static let clientGoogleId = "999900700766-1p4lkal3t54cnljes2blu467p27q9ctf.apps.googleusercontent.com"
    
    static let terms = "I Agree to UDecide Terms & Conditions and Privacy Policy"
    static let googleAPIKey = "AIzaSyCBJTeqe1IAkqZ4ko13XT0T1YUYPiWh3Uo"
    
    
    static let apiKey = "AIzaSyCBJTeqe1IAkqZ4ko13XT0T1YUYPiWh3Uo"
    static let voteSmartApiKey = "yrtC7Mu3f04u1NvfUkSU62JmXB1juTiZ62Etso6f"
    //"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Im1haGxpaWtwYWxtZXJAZ21haWwuY29tIiwicm9sZSI6IlVTRVIiLCJpYXQiOjE3NjE5NzkyMzAsImV4cCI6MTc2MjA2NTYzMH0.xtagXL40LnLqaQLmr4l5JI5daQl21rSVNIdFwz0PVeQ"
    
    static let redColor = #colorLiteral(red: 0.8524393439, green: 0.02895062789, blue: 0.1941759586, alpha: 1)
    static let placeholderColor = #colorLiteral(red: 0.5528928041, green: 0.5529732108, blue: 0.5528674126, alpha: 1)

    static let phoneNumberMaxLength = 14
    static let paswordMaxLength = 15
    static let textFieldMaxLength = 50
    static let zipCodeMaxLength = 10
    
    /**Demo server */
    static let baseUrl = AppServer.live.rawValue
   
    static var iPhoneType: IPhone {
        let screenheight: CGFloat = UIScreen.main.bounds.size.height
        switch screenheight {
        case 568:
            return IPhone.ip5
        case 667:
            return IPhone.ip6
        case 736:
            return IPhone.ip6p
        case 812:
            return IPhone.ipX
		case 896:
			return IPhone.ipXsMax
        default:
            return IPhone.ip4s
        }
    }
    
    static let platform = "iOS"
    static let os_version = UIDevice.current.systemVersion
}

enum IPhone {
    case ip4s
    case ip5
    case ip6
    case ip6p
    case ipX
	case ipXsMax
}

enum fileExtension: String {
    case pdf
    case png
    case jpeg
    case jpg
    case mp4
    case mp3
    case other
}

enum PageCode: String  {
    case aboutus
    case termsconditions
    case privacypolicy
}

enum SocialLoginType: String  {
    case facebook = "FB"
    case google = "G+"
    case apple = "AP"
}

enum AppServer: String {
    case staging = "http://udecideappdev.projectspreview.net/WS"
    case live = "http://52.45.60.139/WS"
    case local = "http://192.168.36.1/udecide_app/WS"

}

enum ReprType: String {
    case fedral
    case state
    case city
    case cabinet
    case county
}
