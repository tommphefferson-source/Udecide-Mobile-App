//
//  PollsAPIRouter.swift
//  Udecide
//
//  Created by hb on 25/04/19.
//  Copyright © 2019 hb. All rights reserved.
//

import Foundation
import Alamofire

enum PollsAPIRouter: RouterProtocol {
    
    var baseUrlString: String {
        return AppConstants.baseUrl
    }
    
    case getPollResult
    case getPolls
    case pollSelect(request: PollSelect.Request)
    
    var method: HTTPMethod {
        return .post
    }
    
    var path: String {
        switch self {
        case .getPollResult:
            return "/poll_results"
        case .getPolls:
            return "/poll_listing"
        case .pollSelect:
            return "/polling"
        }
    }
    
    var parameters: [String: Any]? {
        switch self {
        case .getPollResult:
            return [:]
        case .getPolls:
            return [:]
        case .pollSelect(let request):
            return [
                "poll_id": request.pollId,
                "answer": request.answer,
            ]
        }
    }
    
    var parameterEncoding: ParameterEncoding {
        return URLEncoding.httpBody
    }
    var headers: [String: String]? {
        return ["Content-Type": "application/x-www-form-urlencoded","AUTHTOKEN":UdecideSessionHandler.shared.getLoggedUserDetails()?.authToken ?? ""]
    }
    
    var files: [MultiPartData]? {
        return nil
    }
}
